import { useState, useEffect } from "react";
import './App.css'; // Importing the CSS file here

function App() {
  const [task, setTask] = useState(""); // Store input value
  const [priority, setPriority] = useState("low"); // Store selected priority
  const [dueDate, setDueDate] = useState(""); // Store selected due date
  const [tasks, setTasks] = useState([]); // Store list of tasks
  const [editingIndex, setEditingIndex] = useState(null); // Track task being edited
  const [filter, setFilter] = useState("all"); // Store active filter

  // Load tasks from local storage when the app starts
  useEffect(() => {
    const savedTasks = JSON.parse(localStorage.getItem("tasks"));
    if (savedTasks) {
      setTasks(savedTasks);
    }
  }, []);

  // Save tasks to local storage whenever the tasks change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Add a new task
  const addTask = () => {
    if (task.trim() === "") return; 
    setTasks([...tasks, { text: task, completed: false, priority: priority, dueDate: dueDate }]);
    setTask(""); 
    setPriority("low"); // Reset priority to low after adding the task
    setDueDate(""); // Reset due date after adding the task
  };

  // Update an existing task
  const updateTask = () => {
    if (task.trim() === "") return;
    const updatedTasks = tasks.map((t, index) =>
      index === editingIndex ? { ...t, text: task, priority: priority, dueDate: dueDate } : t
    );
    setTasks(updatedTasks);
    setEditingIndex(null); // Reset editing mode
    setTask(""); // Clear input
    setPriority("low"); // Reset priority
    setDueDate(""); // Reset due date
  };

  // Start editing a task
  const startEditing = (index) => {
    const taskToEdit = tasks[index];
    setTask(taskToEdit.text);
    setPriority(taskToEdit.priority);
    setDueDate(taskToEdit.dueDate);
    setEditingIndex(index); // Set the task to edit
  };

  // Toggle task completion
  const toggleComplete = (index) => {
    setTasks(
      tasks.map((task, i) => 
        i === index ? { ...task, completed: !task.completed } : task
      )
    );
  };

  // Remove task
  const removeTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  // Clear completed tasks
  const clearCompleted = () => {
    setTasks(tasks.filter((task) => !task.completed)); // Remove completed tasks
  };

  // Filter tasks based on active filter
  const filteredTasks = tasks.filter((task) => {
    if (filter === "completed") {
      return task.completed;
    } else if (filter === "active") {
      return !task.completed;
    }
    return true; // "all"
  });

  // Sort tasks by due date (ascending)
  const sortByDueDate = () => {
    const sortedTasks = [...filteredTasks].sort((a, b) => {
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate) - new Date(b.dueDate); // Ascending order
      }
      return 0;
    });
    setTasks(sortedTasks);
  };

  return (
    <div>
      <h1>My To-Do List</h1>
      <input 
        type="text" 
        placeholder="Enter a task..." 
        value={task} 
        onChange={(e) => setTask(e.target.value)} 
      />
      <select value={priority} onChange={(e) => setPriority(e.target.value)}>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
      <input 
        type="date" 
        value={dueDate} 
        onChange={(e) => setDueDate(e.target.value)} 
      />
      {editingIndex !== null ? (
        <button onClick={updateTask}>
          <i className="fas fa-save"></i> Save
        </button>
      ) : (
        <button onClick={addTask}>
          <i className="fas fa-plus"></i> Add Task
        </button>
      )}
      <button onClick={clearCompleted}>
        <i className="fas fa-trash-alt"></i> Clear Completed
      </button>

      <div>
        <button onClick={() => setFilter("all")}>
          <i className="fas fa-list"></i> Show All
        </button>
        <button onClick={() => setFilter("active")}>
          <i className="fas fa-check-circle"></i> Show Active
        </button>
        <button onClick={() => setFilter("completed")}>
          <i className="fas fa-check-double"></i> Show Completed
        </button>
        <button onClick={sortByDueDate}>
          <i className="fas fa-sort"></i> Sort by Due Date
        </button>
      </div>

      <ul>
        {filteredTasks.map((task, index) => (
          <li key={index} className={task.completed ? "completed" : ""}>
            <span onClick={() => startEditing(index)}>
              {task.text} - <strong>{task.priority}</strong> 
              {task.dueDate && ` - Due: ${task.dueDate}`}
            </span>
            <button onClick={() => toggleComplete(index)}>
              {task.completed ? <i className="fas fa-undo"></i> : <i className="fas fa-check"></i>}
            </button>
            <button onClick={() => removeTask(index)}>
              <i className="fas fa-trash"></i>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;